import java.util.*;
import java.io.*;

class Main {
    /* To be loaded from StdIn using input(). */
    int height; // height of image
    int width; // width of image
    int blockHeight; // height of a tiling block
    int blockWidth; // width of a tiling block
    int[][] fReward; // reward for putting pixel in foreground
    int[][] bReward; // reward for putting pixel in background
    int[][] pBtwCols;   // pBtwCols[i][j] is separation penalty between pixel (i,j), (i,j+1)
                        // dimensions: height x (width - 1) 
    int[][] pBtwRows;   // pBtwRows[i][j] is separation penalty between pixel (i,j), (i+1,j)
                        // dimensions: (height-1) x (width)

    /* To be printed to StdOut using output() */
    boolean[][] foreground; // selects the pixels that will go in the foreground

    // Load input from StdIn.
    void input() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            String[] hw = in.readLine().split("\\s+");
            height = Integer.parseInt(hw[0]);
            width = Integer.parseInt(hw[1]);
            String[] bhw = in.readLine().split("\\s+");
            blockHeight = Integer.parseInt(bhw[0]);
            blockWidth = Integer.parseInt(bhw[1]);
            fReward = new int[height][width];
            bReward = new int[height][width];
            pBtwCols = new int[height][width-1];
            pBtwRows = new int[height-1][width];
            // populate fReward
            for (int i = 0; i < height; i++) {
                String[] rewards = in.readLine().split("\\s+");
                for (int j = 0; j < width; j++) {
                    fReward[i][j] = Integer.parseInt(rewards[j]);
                }
            }
            // populate bReward
            for (int i = 0; i < height; i++) {
                String[] rewards = in.readLine().split("\\s+");
                for (int j = 0; j < width; j++) {
                    bReward[i][j] = Integer.parseInt(rewards[j]);
                }
            }
            // populate pBtwColsA
            for (int i = 0; i < height; i++) {
                String[] penalties = in.readLine().split("\\s+");
                for (int j = 0; j < width-1; j++) {
                    pBtwCols[i][j] = Integer.parseInt(penalties[j]);
                }
            }
            // populate pBtwRows
            for (int i = 0; i < height-1; i++) {
                String[] penalties = in.readLine().split("\\s+");
                for (int j = 0; j < width; j++) {
                    pBtwRows[i][j] = Integer.parseInt(penalties[j]);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    String arrToString(boolean[][] arr) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                builder.append(arr[i][j]);
                if (j < arr[i].length-1) {
                    builder.append(" ");
                }
            }
            builder.append("\n");
        }
        return builder.toString();
    }

    // Print output to StdOut.
    void output() {
        try {
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(System.out));
            out.write(arrToString(foreground).replace("true","1").replace("false","0"));
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    class FF
    {
        private int[] parent;
        private Queue<Integer> queue;
        private int n;
        private boolean[] visited;
        private Graph graph;
        private Graph residgraph;
     
        public FF(int n)
        {
            this.n = n;
            this.queue = new LinkedList<Integer>();
            parent = new int[n + 1];
            visited = new boolean[n + 1];
            graph=new Graph (n);
            residgraph=new Graph (n);
        }
        public class Graph {
        	int[][] edgeweights;
        	public Graph (int n) {
        		edgeweights=new int[n+1][n+1];
        	}
        	
        }
        public void addedge (int source, int dest, int weight) {
        	graph.edgeweights[source][dest]=weight;
        	residgraph.edgeweights[source][dest]=weight;
        }
     
        public boolean[] bfs(int source, int goal)
        {
            boolean pathFound = false;
            int destination;
            int element;
     
            for(int vertex = 0; vertex <= n; vertex++)
            {
                parent[vertex] = -1;
                visited[vertex] = false;
            }
     
            queue.add(source);
            parent[source] = -1;
            visited[source] = true;
     
            while (!queue.isEmpty())
            { 
                element = queue.remove();
                destination = 0;
     
                while (destination <= n)
                {
                    if (residgraph.edgeweights[element][destination] > 0 &&  !visited[destination])
                    {
                        parent[destination] = element;
                        queue.add(destination);
                        visited[destination] = true;
                    }
                    destination++;
                }
            }
            if(visited[goal])
            {
                pathFound = true;
            }
            return visited;
        }
     
        public boolean[] fordfulkerson(int source, int destination)
        {
            int u;
            int v;
            int maxFlow = 0;
            int pathFlow;
     
            for (int sV = 0; sV <= n; sV++)
            {
                for (int dV = 0; dV <= n; dV++)
                {
                    residgraph.edgeweights[sV][dV] = graph.edgeweights[sV][dV];
                }
            }
     
            while (bfs(source ,destination)[destination]==true)
            {
                pathFlow = Integer.MAX_VALUE;
                for (v = destination; v != source; v = parent[v])
                {
                    u = parent[v];
                    if (pathFlow>residgraph.edgeweights[u][v]) {
                    	pathFlow=residgraph.edgeweights[u][v];
                    }
                }
                for (v = destination; v != source; v = parent[v])
                {
                    u = parent[v];
                    residgraph.edgeweights[u][v] = residgraph.edgeweights[u][v]-pathFlow;
                    residgraph.edgeweights[v][u] = residgraph.edgeweights[v][u] +pathFlow;
                }
                maxFlow =maxFlow + pathFlow;	
            }
     
            return bfs(source ,destination);
        }
    }

    public Main() {
        input();
    	int numblocksy= height/blockHeight;
    	int numblocksx= width/blockWidth;
    	int totalblocks=numblocksy*numblocksx;
    	int[][] foreblock=new int[numblocksy][numblocksx];
    	int[][] backblock=new int[numblocksy][numblocksx];
        int[][] pblockCols = new int[numblocksy][numblocksx-1];
        int[][] pblockRows = new int[numblocksy-1][numblocksx];
    	for (int i=0; i<numblocksx; i++) {
    		for (int j=0; j<numblocksy; j++) {
    			int startpixelx=i*blockWidth;
    			int startpixely=j*blockHeight;
    			int sumfore=0;
    			int sumback=0;
    			for (int k=0; k<blockWidth; k++) {
    				for(int l=0; l<blockHeight; l++) {
    					sumfore=sumfore+fReward[startpixely+l][startpixelx+k];
    					sumback=sumback+bReward[startpixely+l][startpixelx+k];
    				}
    			}
    			if(i<numblocksx-1) {
    				int sumpencols=0;
    				for(int l=0; l<blockHeight; l++) {
    					if(startpixely+l<height-1 && startpixelx+blockWidth-1<width-1) {
    					sumpencols=sumpencols+pBtwCols[startpixely+l][startpixelx+blockWidth-1];
    					}
    					
    				}
    				int avgcolpen=sumpencols/(blockHeight);
    				pblockCols[j][i]=avgcolpen;
    			}
    			
    			if(j<numblocksy-1) {
    				int sumpenrows=0;
    				for(int k=0; k<blockWidth; k++) {
    					if(startpixely+blockHeight-1<height-1 && startpixelx+k<width) {
    						sumpenrows=sumpenrows+pBtwRows[startpixely+blockHeight-1][startpixelx+k];
    					}
    					
    					
    				}
    				int avgrowpen=sumpenrows/(blockWidth);
    				pblockRows[j][i]=avgrowpen;
    			}
    			
    			
    			int avgfore=sumfore/(blockWidth*blockHeight);
    			int avgback=sumback/(blockWidth*blockHeight);
    			foreblock[j][i]=avgfore;
    			backblock[j][i]=avgback;
    			
    		}
    	}

    	
    	foreground=new boolean[height][width];
        // YOUR CODE HERE
//        for(int i=0; i<height/2;i++) {
//        	for(int j=0; j<width; j++) {
//        		foreground[j][i]=true;
//        	}
//        }
//        for(int i=height/2; i<height;i++) {
//        	for(int j=0; j<width; j++) {
//        		foreground[j][i]=false;
//        	}
//        }
        
        int[][] graph;
        int numNodes;
        int numberofEdges;
        int source;
        int sink;
        int maxFlow;
        numNodes = totalblocks+2;
        numberofEdges = (numblocksx-1)*(numblocksy-1)*2+totalblocks*2;
        FF fordFulkerson = new FF(numNodes);
        for(int i=0; i<numblocksx; i++) {
        	for(int j=0;j<numblocksy;j++) {
        		if(i<numblocksx-1) {
        			int w=pblockCols[j][i];
        			fordFulkerson.addedge(i+j*numblocksx,i+1+j*numblocksx, w);
        			fordFulkerson.addedge(i+1+j*numblocksx,i+j*numblocksx, w);
        		}
        		if(j<numblocksy-1) {
        			int w=pblockRows[j][i];
        			fordFulkerson.addedge(i+j*numblocksx,i+(j+1)*numblocksx, w);
        			fordFulkerson.addedge(i+(j+1)*numblocksx,i+j*numblocksx, w);
        		}
        		int aw;
    			int bw;
        		aw=foreblock[j][i];
        		bw=backblock[j][i];
        		
        		fordFulkerson.addedge(totalblocks,i+j*numblocksx, aw);
        		fordFulkerson.addedge(i+j*numblocksx,totalblocks+1, bw);
        	}
        }
        boolean[] v= fordFulkerson.fordfulkerson(totalblocks, totalblocks+1);
        for (int i=0; i<v.length-3; i++) {
        	int x=i%numblocksx;
        	int y=i/numblocksx;
        	int pixelx= x*blockWidth;
        	int pixely= y*blockHeight;
        	for(int k=0; k<blockWidth;k++) {
               	for(int l=0; l<blockHeight; l++) {
               		//if(pixely+l<height&&pixelx+k<width) {
               			foreground[pixely+l][pixelx+k]=v[i];
               		//}
               		
               	}	
        	}

        }
        
        output();
    }

    public static void main(String[] args) {
        new Main();
    }
}
