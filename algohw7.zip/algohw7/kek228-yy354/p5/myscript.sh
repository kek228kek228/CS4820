for i in `seq 8 22`;
do
echo count: $i
./p5 -t art-full.trace -cache $i 6 1
done
